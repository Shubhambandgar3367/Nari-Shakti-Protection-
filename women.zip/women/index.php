<!DOCTYPE html>
<html class="gr__html5webtemplates_co_uk"><head>
<link rel="stylesheet" href="styles.css">
<link href='https://fonts.googleapis.com/css?family=New Rocker' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Bellefair' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Yatra One' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Bonbon' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Princess Sofia' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Amarante' rel='stylesheet'>
<link rel="icon" href="./images/favicon.png" sizes="16x16">
  <title>Women Safety</title>
  <meta name="description" content="website description">
  <meta name="keywords" content="website keywords, website keywords">
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" type="text/css" href="style.css" title="style">
</head>

<body data-gr-c-s-loaded="true" class="vsc-initialized">
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="#"><span class="logo_colour"> Hey!!! &nbsp</span><span class="logo_colour2">Making Sure Your Safety</span></a></h1>
          <h2>Take care of yourself. Many people out there loves you</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li class="selected"><a href="index.html">Welcome Page</a></li>
          <li><a href="page_one.html">Navigation</a></li>
          <li><a href="page_two.html">Safe Zone</a></li>
          <li><a href="page_three.html">Guardians</a></li>
          <li><a href="page_four.html">Safety Alarm</a></li>
        </ul>
      </div>
    </div>
  </head>

  <body>
  <div class="form-container">
  <header>
      <div class="container">
          <h1>Protect <strong>NARI</strong></h1>
          <nav>
              <ul>
                  <li><a href="#about">About</a></li>
                  <li><a href="#services">Services</a></li>
                  <li><a href="#resources">Resources</a></li>
                  <li><a href="#blog">Blog</a></li>
                  <li><a href="#contact">Contact</a></li>
                  
            <li class="selected"><a href="index.html">Welcome Page</a></li>
            <li><a href="page_one.html">Navigation</a></li>
            <li><a href="page_two.html">Safe Zone</a></li>
            <li><a href="page_three.html">Guardians</a></li>
            <li><a href="page_four.html">Safety Alarm</a></li>
          </ul>
                  <li>
                      <form class="search-form" action="search.php" method="get">
                          <input type="text" name="q" placeholder="Search...">
                          <button type="submit">Search</button>
                      </form>
                  </li>
              </ul>
          </nav>
      </div>
  </header>
  
  <section id="about" class="section">
      <fieldset>
      <legend>About Us</legend>
      <div class="container">
         <i>
  
          <p>Welcome to My Website, a platform dedicated to promoting women's safety and empowerment. At my Website, we believe in creating a safer environment for women by providing information, resources, and support.</p>
          
          <p>Our mission is to raise awareness about women's safety issues, educate individuals on preventive measures, and support initiatives that empower women to lead confident and secure lives.</p>
          
          <p>Through collaborative efforts and community engagement, we strive to make a positive impact on women's safety. Join us in our journey towards a safer and more inclusive world for women.</p>
          </i>
      </div>
  </fieldset>
  </section>
  <section id="services" class="section">
      <fieldset>
          <legend>Our Services</legend>
      <div class="container">
          <div class="service-item">
              <h3>Personal Safety Workshops</h3>
              <p>Empower women with self-defense techniques and situational awareness through our interactive workshops.</p>
          </div>
          <div class="service-item">
              <h3>24/7 Emergency Helpline</h3>
              <p>Provide a dedicated helpline for women in distress, offering immediate support and guidance in emergency situations.</p>
          </div>
          <div class="service-item">
              <h3>Community Awareness Programs</h3>
              <p>Organize programs to raise awareness about women's safety, encouraging community involvement and support.</p>
          </div>
          <div class="service-item">
              <h3>Mobile Safety App</h3>
              <p>Develop a mobile application that offers safety tips, real-time location sharing, and an SOS feature for quick assistance.</p>
          </div>
      </div>
      </fieldset>
  </section>
  <section id="resources" class="section">
      <fieldset>
          <legend>Resources</legend>
      <div class="container">
          
  
          <div class="resource-item">
              <h3>Legal Rights Information</h3>
              <p>Access detailed information about women's legal rights, relevant laws, and steps to take in case of legal concerns.</p>
          </div>
  
          <div class="resource-item">
              <h3>Support Organizations</h3>
              <p>Explore a list of support organizations dedicated to helping women in need, providing counseling, and offering assistance.</p>
          </div>
  
          <div class="resource-item">
              <h3>Educational Materials</h3>
              <p>Find articles, books, and documentaries addressing women's concerns, empowerment, and self-development.</p>
          </div>
      </div>
      </fieldset>
  </section>
  <section id="blog" class="section">
      <fieldset>
          <legend>Blog</legend>
      <div class="container">
          
  
          <article class="blog-post">
              <h3>Empowering Women Through Self-Defense</h3>
              <p>Learn essential self-defense techniques and how they empower women to navigate the world confidently.</p>
              <a href="https://timesofindia.indiatimes.com/blogs/voices/visualizing-womens-safety-and-security-in-india/">Read More</a>
          </article>
  
          <article class="blog-post">
              <h3>Breaking the Silence: Domestic Violence Awareness</h3>
              <p>Explore the importance of raising awareness about domestic violence and supporting survivors.</p>
              <a href="https://pscnotes.in/women-safety-in-india-concern-and-challanges/">Read More</a>
          </article>
  
          <!-- Add more blog posts or articles as needed -->
      </div>
      </fieldset>
  </section>
  <!-- Contact Section -->
  <section id="contact" class="section">
      <fieldset>
          <legend>Contact Us</legend>
      <div class="container">
          
          <p>If you have any questions or need assistance, feel free to reach out to us. Your safety is our priority.</p>
  
          <div class="contact-info">
              <h3>Contact Information</h3>
              <p>Email: protectnari@gmail.com</p>
              <p>Phone: 7666635652</p>
          </div>
  
          <div class="support-services">
              <h3>Support Services</h3>
              <p>If you are in immediate danger, please call emergency services in your Village/Tehsil etc.</p>
              <p>For confidential support and counseling, contact our helpline available 24/7.</p>
          </div>
      </div>
      </fieldset>
  </section>
  
      <form action="personal_info.php" method="post" id="safety-form">
          <fieldset>
              <legend>Personal Information:</legend>
              <label for="full_name">Full Name:</label>
              <input type="text" id="full_name" name="full_name" required>
  
              <label for="dob">Date of Birth:</label>
              <input type="date" id="dob" name="dob" required>
  
              <label for="contact_number">Contact Number:</label>
              <input type="tel" id="contact_number" name="contact_number" required>
  
              <label for="email">Email Address:</label>
              <input type="email" id="email" name="email" required>
  
              <label for="home_address">Home Address:</label>
              <textarea id="home_address" name="home_address" required></textarea>
  
              <label for="visit_date">Preferred Date for Visit:</label>
              <input type="date" id="visit_date" name="visit_date">
  
              <label for="visit_time">Preferred Time for Visit:</label>
              <input type="time" id="visit_time" name="visit_time">
          </fieldset>
          <fieldset>
             
              <legend>Helpline Numbers for Women's Safety in India</legend>
              <ul>
              <li><strong>Women Helpline (All States):</strong> 181</li>
              <li><strong>Domestic Violence Helpline:</strong> 181 (for domestic violence support)</li>
              <li><strong>National Commission for Women (NCW) Helpline:</strong> 011-26942369, 011-26944754</li>
              <li><strong>One Stop Centre (OSC):</strong> Contact local district administration or police</li>
              <li><strong>Police Emergency Number:</strong> 100</li>
              <li><strong>Women's Helpline (Ministry of Women and Child Development):</strong> 1091</li>
              <li><strong>Child Helpline:</strong> 1098 (for reporting child abuse)</li>
              </ul>
          </fieldset>
          <fieldset>
              <legend>Query:</legend>
              <label for="additional-comments">Write Query:</label>
              <textarea id="query" name="query"></textarea>
          </fieldset>
          <fieldset>
              <legend>Consent and Privacy:</legend>
              <p>Please read our <a href="privacy-policy.html" target="_blank">privacy policy</a>.</p>
              <label for="consent">I agree to the terms and conditions:</label>
              <input type="checkbox" id="consent" name="consent" required>
          </fieldset>
  
          <input type="submit" name="submit" value="Save">
      </form>
  </div>
  <footer>
      <div class="container">
          <p>&copy; 2024 Your Website. All rights reserved.</p>
      </div>
  </footer>
 
  
      With Love ❤️ Team Virus vixens<!--| <a href="http://validator.w3.org/check?uri=referer">HTML5</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> | from <a href="http://www.html5webtemplates.co.uk/">free HTML5 templates</a> -->
    </div>
  </div>
</body>
</html>

</body><span class="gr__tooltip"><span class="gr__tooltip-content"></span><i class="gr__tooltip-logo"></i><span class="gr__triangle"></span></span></html>
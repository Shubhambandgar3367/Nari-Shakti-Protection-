<?php

if (isset($_POST["submit"])) {
    // Personal Information
    $fullName = $_POST["full_name"];
    $dateOfBirth = $_POST["dob"];
    $contactNumber = $_POST["contact_number"];
    $email = $_POST["email"];
    $homeAddress = $_POST["home_address"];
    $visitDate = $_POST["visit_date"];
    $visitTime = $_POST["visit_time"];
    $query=$_POST["query"];
    
    $host="localhost";
    $user= "root";
    $pass= "";
    $dbname = "women_safety";

    $conn = mysqli_connect($host, $user, $pass, $dbname);

    $sql = "INSERT INTO personal_info (full_name, dob, contact_number, email, home_address, visit_date, visit_time,query) VALUES ('$fullName', '$dateOfBirth', '$contactNumber', '$email', '$homeAddress', '$visitDate', '$visitTime','$query')";
    mysqli_query($conn,$sql);

} 
?>

